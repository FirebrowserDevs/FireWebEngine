﻿namespace FireWebEngineWinforms_Test
{
    public class Response
    {
    }
}