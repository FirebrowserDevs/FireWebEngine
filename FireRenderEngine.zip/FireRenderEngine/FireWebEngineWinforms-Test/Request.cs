﻿using System.Collections.Generic;

namespace FireWebEngineWinforms_Test
{
    public class Request
    {
        public string Url { get; set; }
        public Dictionary<string, string> Headers { get; set; }
        public string Body { get; set; }

        public Request(string url)
        {
            Url = url;
            Headers = new Dictionary<string, string>();
            Body = string.Empty;
        }

        public void AddHeader(string name, string value)
        {
            Headers[name] = value;
        }

        public void SetBody(string body)
        {
            Body = body;
        }
    }
}