﻿namespace FireWebEngineWinforms_Test
{
    internal interface Pipline
    {
        void PreProcessRequest(Request request);
        void PostProcessResponse(Response response);
        // Add any other methods or members you require for your pipeline
    }
}
