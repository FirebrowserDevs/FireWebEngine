﻿
namespace FireWebEngineWinforms_Test
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.htmlPanel1 = new FireWebEngine.WinForms.HtmlPanel();
            this.htmlToolTip1 = new FireWebEngine.WinForms.HtmlToolTip();
            this.SuspendLayout();
            // 
            // htmlPanel1
            // 
            this.htmlPanel1.AutoScroll = true;
            this.htmlPanel1.AutoScrollMinSize = new System.Drawing.Size(600, 67);
            this.htmlPanel1.BackColor = System.Drawing.SystemColors.Window;
            this.htmlPanel1.BaseStylesheet = null;
            this.htmlPanel1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.htmlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.htmlPanel1.Location = new System.Drawing.Point(0, 0);
            this.htmlPanel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.htmlPanel1.Name = "htmlPanel1";
            this.htmlPanel1.Size = new System.Drawing.Size(600, 366);
            this.htmlPanel1.TabIndex = 0;
            this.htmlPanel1.Text = "<h1>Hello</h1>";
            this.htmlPanel1.UseGdiPlusTextRendering = true;
            this.htmlPanel1.UseSystemCursors = true;
            // 
            // htmlToolTip1
            // 
            this.htmlToolTip1.AllowLinksHandling = true;
            this.htmlToolTip1.AutoPopDelay = 500;
            this.htmlToolTip1.BackColor = System.Drawing.Color.IndianRed;
            this.htmlToolTip1.BaseStylesheet = null;
            this.htmlToolTip1.InitialDelay = 10;
            this.htmlToolTip1.IsBalloon = true;
            this.htmlToolTip1.MaximumSize = new System.Drawing.Size(0, 0);
            this.htmlToolTip1.OwnerDraw = true;
            this.htmlToolTip1.ReshowDelay = 5;
            this.htmlToolTip1.ShowAlways = true;
            this.htmlToolTip1.TooltipCssClass = "htmltooltip";
            this.htmlToolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.htmlToolTip1.ToolTipTitle = "Ui Html";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.htmlPanel1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Engine";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private FireWebEngine.WinForms.HtmlPanel htmlPanel1;
        private FireWebEngine.WinForms.HtmlToolTip htmlToolTip1;
    }
}

