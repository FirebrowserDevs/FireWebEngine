﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FireWebEngineWinforms_Test
{
    public partial class Form1 : Form, Pipline
    {
        public Form1()
        {
            InitializeComponent();


            // Render the HTML content to an image
            Image image = RenderHtmlToImage(html);

            // Display the image in a Windows Forms application
            ShowImage(image);
        }

        private Image RenderHtmlToImage(object html)
        {
            throw new NotImplementedException();
        }

        private void ShowImage(Image image)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            htmlPanel1.IsContextMenuEnabled = true;
            htmlPanel1.Update();
            htmlPanel1.GetHtml();
            htmlPanel1.StylesheetLoad += HtmlPanel1_StylesheetLoad;
            htmlPanel1.Text = "<!DOCTYPE html>\r\n<html lang=\"en-US\">\r\n \r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n    <title id='mydiv'>Today's Date</title>\r\n    <script> $('#mydiv').load('http://localhost/qa/ask#external-div', function(response, status, xhr) {\r\n    if (status == \"error\") {\r\n        var msg = \"Sorry but there was an error: \";\r\n        alert(msg + xhr.status + \" \" + xhr.statusText);\r\n      }\r\n}); </script>\r\n</head>\r\n \r\n<body>\r\n \r\n</body>\r\n \r\n \r\n \r\n</html>";
        }

        public IWin32Window window;
        private object html;

        private void HtmlPanel1_StylesheetLoad(object sender, FireWebEngine.Html.Core.Entities.HtmlStylesheetLoadEventArgs e)
        {   
            htmlPanel1.Update();
            htmlPanel1.GetHtml();
            htmlToolTip1.Show("Test", window);
        }
    }
}
