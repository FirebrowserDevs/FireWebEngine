﻿using System;

namespace FireWebEngine.Html.Adapters
{
    public abstract class RBrush : IDisposable
    {
        public abstract void Dispose();
    }
}
